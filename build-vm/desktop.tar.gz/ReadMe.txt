Steps to get Started:

1. To begin, make sure you have already installed Verily and run the following command on the command prompt from the directory in which you’d like to create your project say 'HelloWorld'

   verily -init <ProjectName>

2. The above command creates a new directory Helloworld. Change the directory to the above directory and create a new Verily Method with the -new

    verily -new <MethodName>

3. This creates a Verily Method/Router Pair in src/main/java folders. 

4. Edit the src/main/java/methods/<MethodName>.java

	package methods;
	import verily.lang.*;
	public class <MethodName> {
	     public static final String sayHello(){
		      return "Hello World";
	     }
	}

5. Edit the src/main/java/routers/<MethodName>.java
	package routers;
	import verily.lang.*;
	public class <MethodName> {
	    public static final Content sayHello(String result) {
		     return new TextContent(result);
	    }
	}

6. Now to run the application, navigate to Project folder and run the command: verily -run
7. It will build and setup the application and provides you the URL where the it is hosted in Terminal output. Lookout for the      	following text in terminal:

	~/Projects/HelloWorld » verily -run

	[INFO] The Following MRR Endpoints Are Available in Your Application:
	[INFO] +----------------------+---------+-----------------+
	[INFO] | ENDPOINT             | METHOD SPEC | VERBS           |
	[INFO] +----------------------+---------+-----------------+
	[INFO] | /<MethodName>/sayHello      | ()      | [POST, GET]     |
	[INFO] +----------------------+---------+-----------------+
	[INFO] ------------------------------------------------------------------------
	[INFO] Verily STARTUP COMPLETE
	[INFO] ------------------------------------------------------------------------
	[INFO] Bootstrapping complete in 4.134 seconds. Verily ready to serve requests at http://localhost:8000/

8.  Visit the URL http://localhost:8000/<MethodName>/sayHello to see the web application in action.

Source:
Above Instructions are from Official Website of Verily by Authors John L.Singleton and Gary T.Leavens. I have slightly abridged it to make it concise.
http://docs.goverily.org/en/latest/quickstart.html#installation
